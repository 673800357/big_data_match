export const api = 'http://180.209.64.50:5000'
//export const api = 'http://192.168.1.85:5000'
export const node_api = 'http://localhost:9000'