module.exports = {
    database:'test',
    username:'root',
    // password:'123456qq',
    host:'localhost',
    jwtsecret:'bigdata'
}